
## 目录说明
.
├── analysis.py          # paddle模型通用日志解析脚本
├── prepare_common.sh    # 提交到PDC后，准备基础环境脚本
├── README.md
└── run_model.sh         # paddle模型通用脚本

